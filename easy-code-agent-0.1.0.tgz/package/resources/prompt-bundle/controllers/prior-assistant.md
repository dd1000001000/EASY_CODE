Prior assistant:
{{content}}
