Thread summary:
{{content}}
