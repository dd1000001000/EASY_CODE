 (truncated)
